function initData() {
  jimData.variables["1"] = "";
  jimData.isInitialized = true;
}