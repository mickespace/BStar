export class LoginRequest {
    userName: string;
    password: string;
    remeberMe: boolean;
}