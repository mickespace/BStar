/**
 *应用评论post-实体
 */
export class CommentPost {
    Star: number;
    Title: string;
    Content: string;
    CreateUserName: string;
    CreateDate: Date;
}