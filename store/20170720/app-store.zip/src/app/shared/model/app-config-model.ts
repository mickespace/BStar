export class AppConfig {
    //api地址
    AppAddress = "http://192.168.10.100:19432/api";
    //AppKey-应用商店Key
    AppStoreKey = "A2E52423-90F9-4F4C-89DB-936B021BEEDD";
}