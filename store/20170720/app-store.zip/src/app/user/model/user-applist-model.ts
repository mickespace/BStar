export class UserApp {
    _id: string;
    DisplayName: string;
    DisplayIcon: string;
    Price: number;
}