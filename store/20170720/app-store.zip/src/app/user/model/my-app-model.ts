/**
 *我的应用-实体
 */
export class MyApp {
    _id: string;
    Name: string;
    Price: number;
    Icon: string;
}